/* SCORM 1.2 API wrapper for Colossyan HTML-to-SCORM */
(function () {
  var API = null;
  var findAttempts = 0;

  function findAPI(win) {
    while (win && findAttempts < 500) {
      if (win.API) return win.API;
      if (win.parent && win.parent !== win) {
        findAttempts += 1;
        win = win.parent;
      } else break;
    }
    return null;
  }

  function getAPI() {
    if (API) return API;
    API = findAPI(window);
    if (!API && window.opener) API = findAPI(window.opener);
    return API;
  }

  function call(fn, arg) {
    var api = getAPI();
    if (!api || typeof api[fn] !== 'function') return 'false';
    try { return api[fn](arg); } catch (e) { return 'false'; }
  }

  window.Scorm12 = {
    initialize: function () { return call('LMSInitialize', ''); },
    finish: function () { return call('LMSFinish', ''); },
    getValue: function (key) { return call('LMSGetValue', key); },
    setValue: function (key, value) { return call('LMSSetValue', key, value); },
    commit: function () { return call('LMSCommit', ''); }
  };
})();